
public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("You live in my dream state");
		System.out.println("Relocate my fantasy");
		System.out.println("I stay in reality");
		System.out.println("You live in my dream state");

	}

}
