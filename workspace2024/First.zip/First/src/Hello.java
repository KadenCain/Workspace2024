// name date purpose
public class Hello {

	public static void main(String[] args) {
		System.out.println("Hello from CSC 151");

	}

}
