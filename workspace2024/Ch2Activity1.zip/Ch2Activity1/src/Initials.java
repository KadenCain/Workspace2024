// Kaden Cain. 1-23-24. Write a program that declares variables named init1, init2, and init3, to hold your three initials. Display the three initials with a period following each one, as in J.M.F.
public class Initials {

	public static void main(String[] args) {
		String init1 = "J", init2 = "M", init3 = "F";
		System.out.println(init1+"."+init2+"."+init3+".");

	}

}
