
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("Hello. My name is Inigo Montoya. You killed my father. Prepare to die.");
		System.out.println("Inigo Montoya");
		System.out.println("The Princess Bride, 1987");

	}

}
